
// {
//   '': {
//     fileKey: '208c891c-5001-7082-96ca-ec759f6f6b74/',
//     fileSize: 0,
//     lastModified: 2023-08-05T20:48:57.000Z
//   },
//   demouser: {
//     'subFolder':{
//       'subFile1':{
//         fileKey: '208c891c-5001-7082-96ca-ec759f6f6b74/demouser/itachi.png',
//         fileSize: 596058,
//         lastModified: 2023-08-05T20:49:32.000Z
//       },
//       'subFile2':{
//         fileKey: '208c891c-5001-7082-96ca-ec759f6f6b74/demouser/itachi.png',
//         fileSize: 596058,
//         lastModified: 2023-08-05T20:49:32.000Z
//       }
//     },
//     'itachi.png': {
//       fileKey: '208c891c-5001-7082-96ca-ec759f6f6b74/demouser/itachi.png',
//       fileSize: 596058,
//       lastModified: 2023-08-05T20:49:32.000Z
//     },
//     'naruto.png': {
//       fileKey: '208c891c-5001-7082-96ca-ec759f6f6b74/demouser/naruto.png',
//       fileSize: 324259,
//       lastModified: 2023-08-05T20:49:32.000Z
//     },
//     'sasuke.png': {
//       fileKey: '208c891c-5001-7082-96ca-ec759f6f6b74/demouser/sasuke.png',
//       fileSize: 230632,
//       lastModified: 2023-08-05T20:49:32.000Z
//     }
//   }
// }
  